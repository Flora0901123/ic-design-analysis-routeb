// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design internal header
// See Vrtlsim_shim.h for the primary calling header

#ifndef VERILATED_VRTLSIM_SHIM_MINI_PHYSICAL_VX_CSA_42__PI286_H_
#define VERILATED_VRTLSIM_SHIM_MINI_PHYSICAL_VX_CSA_42__PI286_H_  // guard

#include "verilated.h"


class Vrtlsim_shim__Syms;

class alignas(VL_CACHE_LINE_BYTES) Vrtlsim_shim_mini_physical_VX_csa_42__pi286 final : public VerilatedModule {
  public:

    // DESIGN SPECIFIC STATE
    VL_IN64(__PVT__a,55,0);
    VL_IN64(__PVT__b,55,0);
    VL_IN64(__PVT__c,55,0);
    VL_IN64(__PVT__d,55,0);
    VL_OUT64(__PVT__sum,57,0);
    VL_OUT64(__PVT__carry,57,0);
    QData/*55:0*/ __PVT__sum_int;
    QData/*55:0*/ __PVT__carry_int;

    // INTERNAL VARIABLES
    Vrtlsim_shim__Syms* const vlSymsp;

    // CONSTRUCTORS
    Vrtlsim_shim_mini_physical_VX_csa_42__pi286(Vrtlsim_shim__Syms* symsp, const char* v__name);
    ~Vrtlsim_shim_mini_physical_VX_csa_42__pi286();
    VL_UNCOPYABLE(Vrtlsim_shim_mini_physical_VX_csa_42__pi286);

    // INTERNAL METHODS
    void __Vconfigure(bool first);
};


#endif  // guard
