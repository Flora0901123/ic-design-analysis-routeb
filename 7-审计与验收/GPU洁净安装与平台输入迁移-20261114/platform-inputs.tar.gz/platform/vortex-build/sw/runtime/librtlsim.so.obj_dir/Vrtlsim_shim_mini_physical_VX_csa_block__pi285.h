// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design internal header
// See Vrtlsim_shim.h for the primary calling header

#ifndef VERILATED_VRTLSIM_SHIM_MINI_PHYSICAL_VX_CSA_BLOCK__PI285_H_
#define VERILATED_VRTLSIM_SHIM_MINI_PHYSICAL_VX_CSA_BLOCK__PI285_H_  // guard

#include "verilated.h"


class Vrtlsim_shim__Syms;

class alignas(VL_CACHE_LINE_BYTES) Vrtlsim_shim_mini_physical_VX_csa_block__pi285 final : public VerilatedModule {
  public:

    // DESIGN SPECIFIC STATE
    // Anonymous structures to workaround compiler member-count bugs
    struct {
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT__cout__BRA__0__KET__;
        CData/*0:0*/ g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__1__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__2__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__3__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__4__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__5__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__6__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__7__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__8__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__9__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__10__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__11__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__12__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__13__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__14__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__15__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__16__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__17__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__18__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__19__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__20__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__21__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__22__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__23__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__24__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__25__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__26__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__27__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__28__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__29__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__30__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__31__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__32__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__33__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__34__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__35__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__36__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__37__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__38__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__39__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__40__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__41__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__42__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__43__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__44__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__45__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__46__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__47__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__0__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__1__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__2__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__3__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__4__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__5__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__6__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__7__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__8__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__9__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__10__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__11__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__12__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__13__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__14__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__15__KET____DOT__u_counter_5to3__DOT__s1;
    };
    struct {
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__16__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__17__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__18__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__19__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__20__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__21__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__22__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__23__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__24__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__25__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__26__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__27__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__28__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__29__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__30__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__31__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__32__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__33__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__34__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__35__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__36__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__37__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__38__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__39__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__40__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__41__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__42__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__43__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__44__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__45__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__46__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__47__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT__cout__BRA__0__KET__;
        CData/*0:0*/ g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__1__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__2__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__3__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__4__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__5__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__6__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__7__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__8__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__9__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__10__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__11__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__12__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__13__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__14__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__15__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__16__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__17__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__18__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__19__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__20__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__21__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__22__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__23__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__24__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__25__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__26__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__27__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__28__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__29__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__30__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__31__KET____DOT__u_counter_5to3__cout;
    };
    struct {
        CData/*0:0*/ g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__32__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__33__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__34__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__35__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__36__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__37__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__38__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__39__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__40__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__41__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__42__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__43__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__44__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__45__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__46__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__47__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT____Vcellout__g_compress_4_2__BRA__48__KET____DOT__u_counter_5to3__cout;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__0__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__1__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__2__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__3__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__4__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__5__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__6__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__7__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__8__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__9__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__10__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__11__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__12__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__13__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__14__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__15__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__16__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__17__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__18__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__19__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__20__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__21__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__22__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__23__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__24__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__25__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__26__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__27__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__28__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__29__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__30__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__31__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__32__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__33__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__34__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__35__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__36__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__37__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__38__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__39__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__40__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__41__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__42__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__43__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__44__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__45__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__46__KET____DOT__u_counter_5to3__DOT__s1;
    };
    struct {
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__47__KET____DOT__u_counter_5to3__DOT__s1;
        CData/*0:0*/ __PVT__g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT__g_compress_4_2__BRA__48__KET____DOT__u_counter_5to3__DOT__s1;
        VL_INW(__PVT__operands,287,0,9);
        VL_OUT64(__PVT__sum,55,0);
        VL_OUT64(__PVT__carry,55,0);
        QData/*49:0*/ __PVT__g_4to2_levels__BRA__0__KET____DOT__ct;
        QData/*47:0*/ __Vcellinp__g_4to2_levels__BRA__0__KET____DOT__csa_42__d;
        QData/*47:0*/ __Vcellinp__g_4to2_levels__BRA__0__KET____DOT__csa_42__c;
        QData/*47:0*/ __Vcellinp__g_4to2_levels__BRA__0__KET____DOT__csa_42__b;
        QData/*47:0*/ __Vcellinp__g_4to2_levels__BRA__0__KET____DOT__csa_42__a;
        QData/*48:0*/ __Vcellinp__g_4to2_levels__BRA__1__KET____DOT__csa_42__d;
        QData/*48:0*/ __Vcellinp__g_4to2_levels__BRA__1__KET____DOT__csa_42__c;
        QData/*48:0*/ __Vcellinp__g_4to2_levels__BRA__1__KET____DOT__csa_42__b;
        QData/*48:0*/ __Vcellinp__g_4to2_levels__BRA__1__KET____DOT__csa_42__a;
        QData/*47:0*/ __PVT__g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT__sum_int;
        QData/*47:0*/ __PVT__g_4to2_levels__BRA__0__KET____DOT__csa_42__DOT__carry_int;
        QData/*48:0*/ __PVT__g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT__sum_int;
        QData/*48:0*/ __PVT__g_4to2_levels__BRA__1__KET____DOT__csa_42__DOT__carry_int;
        VlUnpacked<QData/*55:0*/, 3> __PVT__St;
        VlUnpacked<QData/*55:0*/, 3> __PVT__Ct;
    };

    // INTERNAL VARIABLES
    Vrtlsim_shim__Syms* const vlSymsp;

    // CONSTRUCTORS
    Vrtlsim_shim_mini_physical_VX_csa_block__pi285(Vrtlsim_shim__Syms* symsp, const char* v__name);
    ~Vrtlsim_shim_mini_physical_VX_csa_block__pi285();
    VL_UNCOPYABLE(Vrtlsim_shim_mini_physical_VX_csa_block__pi285);

    // INTERNAL METHODS
    void __Vconfigure(bool first);
};


#endif  // guard
