// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design internal header
// See Vrtlsim_shim.h for the primary calling header

#ifndef VERILATED_VRTLSIM_SHIM_MINI_PHYSICAL_VX_FMA_UNIT__L8_H_
#define VERILATED_VRTLSIM_SHIM_MINI_PHYSICAL_VX_FMA_UNIT__L8_H_  // guard

#include "verilated.h"
class Vrtlsim_shim_mini_physical_VX_csa_42__pi286;
class Vrtlsim_shim_mini_physical_VX_csa_block__pi285;


class Vrtlsim_shim__Syms;

class alignas(VL_CACHE_LINE_BYTES) Vrtlsim_shim_mini_physical_VX_fma_unit__L8 final : public VerilatedModule {
  public:
    // CELLS
    Vrtlsim_shim_mini_physical_VX_csa_block__pi285* __PVT__g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT__g_do_cluster__DOT__g_clusters__BRA__0__KET____DOT__g_lin__DOT__cluster_linear;
    Vrtlsim_shim_mini_physical_VX_csa_block__pi285* __PVT__g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT__g_do_cluster__DOT__g_clusters__BRA__1__KET____DOT__g_lin__DOT__cluster_linear;
    Vrtlsim_shim_mini_physical_VX_csa_block__pi285* __PVT__g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT__g_do_cluster__DOT__g_clusters__BRA__2__KET____DOT__g_lin__DOT__cluster_linear;
    Vrtlsim_shim_mini_physical_VX_csa_block__pi285* __PVT__g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT__g_do_cluster__DOT__g_clusters__BRA__3__KET____DOT__g_lin__DOT__cluster_linear;
    Vrtlsim_shim_mini_physical_VX_csa_42__pi286* __PVT__g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT__g_levels__BRA__0__KET____DOT__g_balanced__DOT__g_core__BRA__0__KET____DOT__csa;
    Vrtlsim_shim_mini_physical_VX_csa_42__pi286* __PVT__g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT__g_levels__BRA__0__KET____DOT__g_balanced__DOT__g_core__BRA__1__KET____DOT__csa;

    // DESIGN SPECIFIC STATE
    // Anonymous structures to workaround compiler member-count bugs
    struct {
        VL_IN8(clk,0,0);
        VL_IN8(reset,0,0);
        VL_IN8(enable,0,0);
        VL_IN8(mask,0,0);
        VL_IN8(op_type,3,0);
        VL_IN8(fmt,1,0);
        VL_IN8(frm,2,0);
        VL_OUT8(fflags,4,0);
        CData/*0:0*/ g_rtl__DOT__core__DOT____Vxrand___2;
        CData/*0:0*/ g_rtl__DOT__core__DOT____Vxrand___1;
        CData/*0:0*/ g_rtl__DOT__core__DOT____Vxrand___0;
        CData/*7:0*/ __PVT__g_rtl__DOT__core__DOT__mask_pipe;
        CData/*0:0*/ __PVT__g_rtl__DOT__core__DOT__s_c0;
        CData/*6:0*/ __PVT__g_rtl__DOT__core__DOT__clss_a0;
        CData/*6:0*/ __PVT__g_rtl__DOT__core__DOT__clss_b0;
        CData/*6:0*/ __PVT__g_rtl__DOT__core__DOT__clss_c0;
        CData/*0:0*/ __PVT__g_rtl__DOT__core__DOT__s_prod0;
        CData/*0:0*/ __PVT__g_rtl__DOT__core__DOT__prod_is_inf;
        CData/*0:0*/ __PVT__g_rtl__DOT__core__DOT__nv_inf_inf;
        CData/*0:0*/ __PVT__g_rtl__DOT__core__DOT__early_nv;
        CData/*0:0*/ __PVT__g_rtl__DOT__core__DOT__result_nan;
        CData/*0:0*/ g_rtl__DOT__core__DOT____Vcellinp__pipe_ini__enable;
        CData/*0:0*/ __PVT__g_rtl__DOT__core__DOT__prod_ge_c;
        CData/*0:0*/ g_rtl__DOT__core__DOT____Vcellinp__pipe_aln__enable;
        CData/*0:0*/ __PVT__g_rtl__DOT__core__DOT__prod_gte_c;
        CData/*0:0*/ g_rtl__DOT__core__DOT____Vcellinp__pipe_acc__enable;
        CData/*0:0*/ g_rtl__DOT__core__DOT____Vcellinp__pipe_nrm__enable;
        CData/*0:0*/ g_rtl__DOT__core__DOT____Vcellinp__pipe_rnd1__enable;
        CData/*4:0*/ __PVT__g_rtl__DOT__core__DOT__rnd_fflags;
        CData/*0:0*/ g_rtl__DOT__core__DOT____Vcellinp__pipe_rnd__enable;
        CData/*5:0*/ __Vfunc_g_rtl__DOT__core__DOT__sv2v_cast_03E1C_signed__19__Vfuncout;
        CData/*5:0*/ __Vfunc_g_rtl__DOT__core__DOT__sv2v_cast_03E1C_signed__19__inp;
        CData/*5:0*/ __Vfunc_g_rtl__DOT__core__DOT__sv2v_cast_081B2_signed__32__Vfuncout;
        CData/*5:0*/ __Vfunc_g_rtl__DOT__core__DOT__sv2v_cast_081B2_signed__32__inp;
        CData/*1:0*/ __Vfunc_g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT__next_lev_balanced__106___sv2v_jump;
        CData/*5:0*/ __Vfunc_g_rtl__DOT__core__DOT__sv2v_cast_03E1C_signed__142__Vfuncout;
        CData/*5:0*/ __Vfunc_g_rtl__DOT__core__DOT__sv2v_cast_03E1C_signed__142__inp;
        CData/*5:0*/ __Vfunc_g_rtl__DOT__core__DOT__sv2v_cast_081B2_signed__155__Vfuncout;
        CData/*5:0*/ __Vfunc_g_rtl__DOT__core__DOT__sv2v_cast_081B2_signed__155__inp;
        CData/*1:0*/ __Vfunc_g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT__next_lev_balanced__229___sv2v_jump;
        CData/*5:0*/ __Vfunc_g_rtl__DOT__core__DOT__sv2v_cast_03E1C_signed__265__Vfuncout;
        CData/*5:0*/ __Vfunc_g_rtl__DOT__core__DOT__sv2v_cast_03E1C_signed__265__inp;
        CData/*5:0*/ __Vfunc_g_rtl__DOT__core__DOT__sv2v_cast_081B2_signed__278__Vfuncout;
        CData/*5:0*/ __Vfunc_g_rtl__DOT__core__DOT__sv2v_cast_081B2_signed__278__inp;
        CData/*1:0*/ __Vfunc_g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT__next_lev_balanced__352___sv2v_jump;
        CData/*5:0*/ __Vfunc_g_rtl__DOT__core__DOT__sv2v_cast_03E1C_signed__388__Vfuncout;
        CData/*5:0*/ __Vfunc_g_rtl__DOT__core__DOT__sv2v_cast_03E1C_signed__388__inp;
        CData/*5:0*/ __Vfunc_g_rtl__DOT__core__DOT__sv2v_cast_081B2_signed__401__Vfuncout;
        CData/*5:0*/ __Vfunc_g_rtl__DOT__core__DOT__sv2v_cast_081B2_signed__401__inp;
        CData/*1:0*/ __Vfunc_g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT__next_lev_balanced__475___sv2v_jump;
        SData/*9:0*/ __PVT__g_rtl__DOT__core__DOT__exp_a;
        SData/*9:0*/ __PVT__g_rtl__DOT__core__DOT__exp_b;
        SData/*9:0*/ __PVT__g_rtl__DOT__core__DOT__exp_c;
        SData/*9:0*/ __PVT__g_rtl__DOT__core__DOT__nrm_exp_base;
        SData/*9:0*/ __Vfunc_g_rtl__DOT__core__DOT__sv2v_cast_E0AE2__6__Vfuncout;
        SData/*9:0*/ __Vfunc_g_rtl__DOT__core__DOT__sv2v_cast_E0AE2__6__inp;
        SData/*9:0*/ __Vfunc_g_rtl__DOT__core__DOT__sv2v_cast_E0AE2__9__Vfuncout;
        SData/*9:0*/ __Vfunc_g_rtl__DOT__core__DOT__sv2v_cast_E0AE2__9__inp;
        SData/*9:0*/ __Vfunc_g_rtl__DOT__core__DOT__sv2v_cast_E0AE2__13__Vfuncout;
        SData/*9:0*/ __Vfunc_g_rtl__DOT__core__DOT__sv2v_cast_E0AE2__13__inp;
        SData/*9:0*/ __Vfunc_g_rtl__DOT__core__DOT__sv2v_cast_E0AE2__23__Vfuncout;
        SData/*9:0*/ __Vfunc_g_rtl__DOT__core__DOT__sv2v_cast_E0AE2__23__inp;
        SData/*9:0*/ __Vfunc_g_rtl__DOT__core__DOT__sv2v_cast_E0AE2__129__Vfuncout;
        SData/*9:0*/ __Vfunc_g_rtl__DOT__core__DOT__sv2v_cast_E0AE2__129__inp;
    };
    struct {
        SData/*9:0*/ __Vfunc_g_rtl__DOT__core__DOT__sv2v_cast_E0AE2__132__Vfuncout;
        SData/*9:0*/ __Vfunc_g_rtl__DOT__core__DOT__sv2v_cast_E0AE2__132__inp;
        SData/*9:0*/ __Vfunc_g_rtl__DOT__core__DOT__sv2v_cast_E0AE2__136__Vfuncout;
        SData/*9:0*/ __Vfunc_g_rtl__DOT__core__DOT__sv2v_cast_E0AE2__136__inp;
        SData/*9:0*/ __Vfunc_g_rtl__DOT__core__DOT__sv2v_cast_E0AE2__146__Vfuncout;
        SData/*9:0*/ __Vfunc_g_rtl__DOT__core__DOT__sv2v_cast_E0AE2__146__inp;
        SData/*9:0*/ __Vfunc_g_rtl__DOT__core__DOT__sv2v_cast_E0AE2__252__Vfuncout;
        SData/*9:0*/ __Vfunc_g_rtl__DOT__core__DOT__sv2v_cast_E0AE2__252__inp;
        SData/*9:0*/ __Vfunc_g_rtl__DOT__core__DOT__sv2v_cast_E0AE2__255__Vfuncout;
        SData/*9:0*/ __Vfunc_g_rtl__DOT__core__DOT__sv2v_cast_E0AE2__255__inp;
        SData/*9:0*/ __Vfunc_g_rtl__DOT__core__DOT__sv2v_cast_E0AE2__259__Vfuncout;
        SData/*9:0*/ __Vfunc_g_rtl__DOT__core__DOT__sv2v_cast_E0AE2__259__inp;
        SData/*9:0*/ __Vfunc_g_rtl__DOT__core__DOT__sv2v_cast_E0AE2__269__Vfuncout;
        SData/*9:0*/ __Vfunc_g_rtl__DOT__core__DOT__sv2v_cast_E0AE2__269__inp;
        SData/*9:0*/ __Vfunc_g_rtl__DOT__core__DOT__sv2v_cast_E0AE2__375__Vfuncout;
        SData/*9:0*/ __Vfunc_g_rtl__DOT__core__DOT__sv2v_cast_E0AE2__375__inp;
        SData/*9:0*/ __Vfunc_g_rtl__DOT__core__DOT__sv2v_cast_E0AE2__378__Vfuncout;
        SData/*9:0*/ __Vfunc_g_rtl__DOT__core__DOT__sv2v_cast_E0AE2__378__inp;
        SData/*9:0*/ __Vfunc_g_rtl__DOT__core__DOT__sv2v_cast_E0AE2__382__Vfuncout;
        SData/*9:0*/ __Vfunc_g_rtl__DOT__core__DOT__sv2v_cast_E0AE2__382__inp;
        SData/*9:0*/ __Vfunc_g_rtl__DOT__core__DOT__sv2v_cast_E0AE2__392__Vfuncout;
        SData/*9:0*/ __Vfunc_g_rtl__DOT__core__DOT__sv2v_cast_E0AE2__392__inp;
        VL_IN(dataa,31,0);
        VL_IN(datab,31,0);
        VL_IN(datac,31,0);
        VL_OUT(result,31,0);
        IData/*31:0*/ __PVT__g_rtl__DOT__core__DOT__op_a;
        IData/*31:0*/ __PVT__g_rtl__DOT__core__DOT__op_b;
        IData/*22:0*/ __PVT__g_rtl__DOT__core__DOT__m_c0;
        VlWide<4>/*104:0*/ g_rtl__DOT__core__DOT____Vcellinp__pipe_rnd1__data_in;
        IData/*23:0*/ __PVT__g_rtl__DOT__core__DOT__sub_abs;
        VlWide<4>/*101:0*/ __PVT__g_rtl__DOT__core__DOT__g_align_single__DOT__full_sh;
        VlWide<4>/*100:0*/ __PVT__g_rtl__DOT__core__DOT__pipe_ini__DOT__g_pipe__DOT__g_no_reset__DOT__pipe;
        VlWide<4>/*105:0*/ __PVT__g_rtl__DOT__core__DOT__pipe_side__DOT__g_pipe__DOT__g_no_reset__DOT__pipe;
        VlWide<4>/*122:0*/ __PVT__g_rtl__DOT__core__DOT__pipe_aln__DOT__g_pipe__DOT__g_no_reset__DOT__pipe;
        VlWide<10>/*311:0*/ __PVT__g_rtl__DOT__core__DOT__lzc_inst__DOT__g_lzc__DOT__indices;
        VlWide<3>/*77:0*/ __PVT__g_rtl__DOT__core__DOT__pipe_acc__DOT__g_pipe__DOT__g_no_reset__DOT__pipe;
        VlWide<3>/*69:0*/ __PVT__g_rtl__DOT__core__DOT__pipe_nrm__DOT__g_pipe__DOT__g_no_reset__DOT__pipe;
        VlWide<4>/*104:0*/ __PVT__g_rtl__DOT__core__DOT__pipe_rnd1__DOT__g_pipe__DOT__g_no_reset__DOT__pipe;
        VlWide<36>/*1151:0*/ __PVT__g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp;
        VlWide<14>/*447:0*/ __PVT__g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT__tree_inputs;
        VlWide<3>/*95:0*/ __PVT__g_rtl__DOT__core__DOT__g_mul_wallace__DOT__pm__DOT__g_pipe__DOT__g_no_reset__DOT__pipe;
        IData/*31:0*/ __Vfunc_g_rtl__DOT__core__DOT__daz_f__2__Vfuncout;
        IData/*31:0*/ __Vfunc_g_rtl__DOT__core__DOT__daz_f__2__v;
        IData/*31:0*/ __Vfunc_g_rtl__DOT__core__DOT__daz_f__3__Vfuncout;
        IData/*31:0*/ __Vfunc_g_rtl__DOT__core__DOT__daz_f__3__v;
        IData/*31:0*/ __Vfunc_g_rtl__DOT__core__DOT__daz_f__4__Vfuncout;
        IData/*31:0*/ __Vfunc_g_rtl__DOT__core__DOT__daz_f__4__v;
        IData/*31:0*/ __Vfunc_g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT__get_cnt_at_lev__104__Vfuncout;
        IData/*31:0*/ __Vfunc_g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT__get_cnt_at_lev__104__l;
        IData/*31:0*/ __Vfunc_g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT__get_cnt_at_lev__104__sv2v_autoblock_1__DOT__k;
        IData/*31:0*/ __Vfunc_g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT__get_cnt_at_lev__104__c;
        IData/*31:0*/ __Vfunc_g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT__get_next_sz__105__Vfuncout;
        IData/*31:0*/ __Vfunc_g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT__get_next_sz__105__n;
        IData/*31:0*/ __Vfunc_g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT__next_lev_balanced__106__Vfuncout;
        IData/*31:0*/ __Vfunc_g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT__next_lev_balanced__106__n_in;
        IData/*31:0*/ __Vfunc_g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT__next_lev_balanced__106__n_rem;
        IData/*31:0*/ __Vfunc_g_rtl__DOT__core__DOT__daz_f__125__Vfuncout;
        IData/*31:0*/ __Vfunc_g_rtl__DOT__core__DOT__daz_f__125__v;
        IData/*31:0*/ __Vfunc_g_rtl__DOT__core__DOT__daz_f__126__Vfuncout;
        IData/*31:0*/ __Vfunc_g_rtl__DOT__core__DOT__daz_f__126__v;
        IData/*31:0*/ __Vfunc_g_rtl__DOT__core__DOT__daz_f__127__Vfuncout;
        IData/*31:0*/ __Vfunc_g_rtl__DOT__core__DOT__daz_f__127__v;
        IData/*31:0*/ __Vfunc_g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT__get_cnt_at_lev__227__Vfuncout;
    };
    struct {
        IData/*31:0*/ __Vfunc_g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT__get_cnt_at_lev__227__l;
        IData/*31:0*/ __Vfunc_g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT__get_cnt_at_lev__227__sv2v_autoblock_1__DOT__k;
        IData/*31:0*/ __Vfunc_g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT__get_cnt_at_lev__227__c;
        IData/*31:0*/ __Vfunc_g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT__get_next_sz__228__Vfuncout;
        IData/*31:0*/ __Vfunc_g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT__get_next_sz__228__n;
        IData/*31:0*/ __Vfunc_g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT__next_lev_balanced__229__Vfuncout;
        IData/*31:0*/ __Vfunc_g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT__next_lev_balanced__229__n_in;
        IData/*31:0*/ __Vfunc_g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT__next_lev_balanced__229__n_rem;
        IData/*31:0*/ __Vfunc_g_rtl__DOT__core__DOT__daz_f__248__Vfuncout;
        IData/*31:0*/ __Vfunc_g_rtl__DOT__core__DOT__daz_f__248__v;
        IData/*31:0*/ __Vfunc_g_rtl__DOT__core__DOT__daz_f__249__Vfuncout;
        IData/*31:0*/ __Vfunc_g_rtl__DOT__core__DOT__daz_f__249__v;
        IData/*31:0*/ __Vfunc_g_rtl__DOT__core__DOT__daz_f__250__Vfuncout;
        IData/*31:0*/ __Vfunc_g_rtl__DOT__core__DOT__daz_f__250__v;
        IData/*31:0*/ __Vfunc_g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT__get_cnt_at_lev__350__Vfuncout;
        IData/*31:0*/ __Vfunc_g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT__get_cnt_at_lev__350__l;
        IData/*31:0*/ __Vfunc_g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT__get_cnt_at_lev__350__sv2v_autoblock_1__DOT__k;
        IData/*31:0*/ __Vfunc_g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT__get_cnt_at_lev__350__c;
        IData/*31:0*/ __Vfunc_g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT__get_next_sz__351__Vfuncout;
        IData/*31:0*/ __Vfunc_g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT__get_next_sz__351__n;
        IData/*31:0*/ __Vfunc_g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT__next_lev_balanced__352__Vfuncout;
        IData/*31:0*/ __Vfunc_g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT__next_lev_balanced__352__n_in;
        IData/*31:0*/ __Vfunc_g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT__next_lev_balanced__352__n_rem;
        IData/*31:0*/ __Vfunc_g_rtl__DOT__core__DOT__daz_f__371__Vfuncout;
        IData/*31:0*/ __Vfunc_g_rtl__DOT__core__DOT__daz_f__371__v;
        IData/*31:0*/ __Vfunc_g_rtl__DOT__core__DOT__daz_f__372__Vfuncout;
        IData/*31:0*/ __Vfunc_g_rtl__DOT__core__DOT__daz_f__372__v;
        IData/*31:0*/ __Vfunc_g_rtl__DOT__core__DOT__daz_f__373__Vfuncout;
        IData/*31:0*/ __Vfunc_g_rtl__DOT__core__DOT__daz_f__373__v;
        IData/*31:0*/ __Vfunc_g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT__get_cnt_at_lev__473__Vfuncout;
        IData/*31:0*/ __Vfunc_g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT__get_cnt_at_lev__473__l;
        IData/*31:0*/ __Vfunc_g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT__get_cnt_at_lev__473__sv2v_autoblock_1__DOT__k;
        IData/*31:0*/ __Vfunc_g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT__get_cnt_at_lev__473__c;
        IData/*31:0*/ __Vfunc_g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT__get_next_sz__474__Vfuncout;
        IData/*31:0*/ __Vfunc_g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT__get_next_sz__474__n;
        IData/*31:0*/ __Vfunc_g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT__next_lev_balanced__475__Vfuncout;
        IData/*31:0*/ __Vfunc_g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT__next_lev_balanced__475__n_in;
        IData/*31:0*/ __Vfunc_g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT__next_lev_balanced__475__n_rem;
        QData/*50:0*/ __PVT__g_rtl__DOT__core__DOT__fixed_op;
        QData/*51:0*/ __PVT__g_rtl__DOT__core__DOT__acc_sum;
        QData/*52:0*/ __PVT__g_rtl__DOT__core__DOT__shifted_raw;
        QData/*47:0*/ __PVT__g_rtl__DOT__core__DOT__g_mul_wallace__DOT__wal_prod;
        QData/*52:0*/ g_rtl__DOT__core__DOT__pipe_side__DOT____Vlvbound_h374fdbfd__0;
        QData/*36:0*/ __PVT__g_rtl__DOT__core__DOT__pipe_rnd__DOT__g_pipe__DOT__g_no_reset__DOT__pipe;
        QData/*55:0*/ g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT____Vcellinp__g_levels__BRA__0__KET____DOT__g_balanced__DOT__g_core__BRA__0__KET____DOT__csa__d;
        QData/*55:0*/ g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT____Vcellinp__g_levels__BRA__0__KET____DOT__g_balanced__DOT__g_core__BRA__0__KET____DOT__csa__c;
        QData/*55:0*/ g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT____Vcellinp__g_levels__BRA__0__KET____DOT__g_balanced__DOT__g_core__BRA__0__KET____DOT__csa__b;
        QData/*55:0*/ g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT____Vcellinp__g_levels__BRA__0__KET____DOT__g_balanced__DOT__g_core__BRA__0__KET____DOT__csa__a;
        QData/*55:0*/ g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT____Vcellinp__g_levels__BRA__0__KET____DOT__g_balanced__DOT__g_core__BRA__1__KET____DOT__csa__d;
        QData/*55:0*/ g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT____Vcellinp__g_levels__BRA__0__KET____DOT__g_balanced__DOT__g_core__BRA__1__KET____DOT__csa__c;
        QData/*55:0*/ g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT____Vcellinp__g_levels__BRA__0__KET____DOT__g_balanced__DOT__g_core__BRA__1__KET____DOT__csa__b;
        QData/*55:0*/ g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT____Vcellinp__g_levels__BRA__0__KET____DOT__g_balanced__DOT__g_core__BRA__1__KET____DOT__csa__a;
        QData/*57:0*/ __PVT__g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT__g_levels__BRA__1__KET____DOT__g_balanced__DOT__g_core__BRA__0__KET____DOT__csa__DOT__sum_int;
        QData/*57:0*/ __PVT__g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT__g_levels__BRA__1__KET____DOT__g_balanced__DOT__g_core__BRA__0__KET____DOT__csa__DOT__carry_int;
        QData/*47:0*/ g_rtl__DOT__core__DOT__g_mul_wallace__DOT__pm__DOT____Vlvbound_h3f88ce68__0;
        QData/*51:0*/ __Vfunc_g_rtl__DOT__core__DOT__sv2v_cast_F776F__21__Vfuncout;
        QData/*51:0*/ __Vfunc_g_rtl__DOT__core__DOT__sv2v_cast_F776F__21__inp;
        QData/*47:0*/ __Vfunc_g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT__sv2v_cast_50907__108__Vfuncout;
        QData/*47:0*/ __Vfunc_g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT__sv2v_cast_50907__108__inp;
        QData/*51:0*/ __Vfunc_g_rtl__DOT__core__DOT__sv2v_cast_F776F__144__Vfuncout;
        QData/*51:0*/ __Vfunc_g_rtl__DOT__core__DOT__sv2v_cast_F776F__144__inp;
        QData/*47:0*/ __Vfunc_g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT__sv2v_cast_50907__231__Vfuncout;
        QData/*47:0*/ __Vfunc_g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT__sv2v_cast_50907__231__inp;
        QData/*51:0*/ __Vfunc_g_rtl__DOT__core__DOT__sv2v_cast_F776F__267__Vfuncout;
    };
    struct {
        QData/*51:0*/ __Vfunc_g_rtl__DOT__core__DOT__sv2v_cast_F776F__267__inp;
        QData/*47:0*/ __Vfunc_g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT__sv2v_cast_50907__354__Vfuncout;
        QData/*47:0*/ __Vfunc_g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT__sv2v_cast_50907__354__inp;
        QData/*51:0*/ __Vfunc_g_rtl__DOT__core__DOT__sv2v_cast_F776F__390__Vfuncout;
        QData/*51:0*/ __Vfunc_g_rtl__DOT__core__DOT__sv2v_cast_F776F__390__inp;
        QData/*47:0*/ __Vfunc_g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT__sv2v_cast_50907__477__Vfuncout;
        QData/*47:0*/ __Vfunc_g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__pp_acc__DOT__sv2v_cast_50907__477__inp;
        VlUnpacked<CData/*0:0*/, 127> __PVT__g_rtl__DOT__core__DOT__lzc_inst__DOT__g_lzc__DOT__find_first__DOT__s_n;
        VlUnpacked<CData/*5:0*/, 127> __PVT__g_rtl__DOT__core__DOT__lzc_inst__DOT__g_lzc__DOT__find_first__DOT__d_n;
        VlUnpacked<QData/*47:0*/, 7> __PVT__g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__final_add__DOT__g_KS__DOT__G;
        VlUnpacked<QData/*47:0*/, 7> __PVT__g_rtl__DOT__core__DOT__g_mul_wallace__DOT__u_mul__DOT__final_add__DOT__g_KS__DOT__P;
    };

    // INTERNAL VARIABLES
    Vrtlsim_shim__Syms* const vlSymsp;

    // CONSTRUCTORS
    Vrtlsim_shim_mini_physical_VX_fma_unit__L8(Vrtlsim_shim__Syms* symsp, const char* v__name);
    ~Vrtlsim_shim_mini_physical_VX_fma_unit__L8();
    VL_UNCOPYABLE(Vrtlsim_shim_mini_physical_VX_fma_unit__L8);

    // INTERNAL METHODS
    void __Vconfigure(bool first);
};


#endif  // guard
