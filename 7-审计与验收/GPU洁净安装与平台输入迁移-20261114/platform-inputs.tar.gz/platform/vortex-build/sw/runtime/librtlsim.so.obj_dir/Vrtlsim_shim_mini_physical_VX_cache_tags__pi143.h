// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design internal header
// See Vrtlsim_shim.h for the primary calling header

#ifndef VERILATED_VRTLSIM_SHIM_MINI_PHYSICAL_VX_CACHE_TAGS__PI143_H_
#define VERILATED_VRTLSIM_SHIM_MINI_PHYSICAL_VX_CACHE_TAGS__PI143_H_  // guard

#include "verilated.h"


class Vrtlsim_shim__Syms;

class alignas(VL_CACHE_LINE_BYTES) Vrtlsim_shim_mini_physical_VX_cache_tags__pi143 final : public VerilatedModule {
  public:

    // DESIGN SPECIFIC STATE
    // Anonymous structures to workaround compiler member-count bugs
    struct {
        VL_IN8(clk,0,0);
        VL_IN8(reset,0,0);
        VL_IN8(stall,0,0);
        VL_IN8(init,0,0);
        VL_IN8(flush,0,0);
        VL_IN8(fill,0,0);
        VL_IN8(read,0,0);
        VL_IN8(write,0,0);
        VL_IN8(invalidate,0,0);
        VL_IN8(line_idx,4,0);
        VL_IN8(line_idx_n,4,0);
        VL_IN8(sector_idx,0,0);
        VL_IN8(evict_way,1,0);
        VL_IN8(fill_way_oh,3,0);
        VL_OUT8(tag_matches,3,0);
        VL_OUT8(line_present,3,0);
        VL_OUT8(evict_dirty,0,0);
        VL_OUT8(evict_dirty_mask,0,0);
        CData/*3:0*/ __PVT__read_valid;
        CData/*3:0*/ __PVT__read_dirty;
        CData/*3:0*/ __PVT__line_write;
        CData/*3:0*/ __PVT__valid_wren;
        CData/*3:0*/ __PVT__valid_wdata;
        CData/*3:0*/ __PVT__dirty_wren;
        CData/*3:0*/ __PVT__dirty_wdata;
        CData/*0:0*/ __PVT__g_way_decode__BRA__0__KET____DOT__do_fill;
        CData/*0:0*/ __PVT__g_way_decode__BRA__0__KET____DOT__do_write;
        CData/*0:0*/ __PVT__g_way_decode__BRA__0__KET____DOT__fill_refill;
        CData/*0:0*/ __PVT__g_way_decode__BRA__0__KET____DOT__g_dirty__DOT__dclr_all;
        CData/*0:0*/ __PVT__g_way_decode__BRA__0__KET____DOT__g_dirty__DOT__dclr_oh;
        CData/*0:0*/ __PVT__g_way_decode__BRA__0__KET____DOT__g_dirty__DOT__same_set;
        CData/*0:0*/ __PVT__g_way_decode__BRA__1__KET____DOT__do_fill;
        CData/*0:0*/ __PVT__g_way_decode__BRA__1__KET____DOT__do_write;
        CData/*0:0*/ __PVT__g_way_decode__BRA__1__KET____DOT__fill_refill;
        CData/*0:0*/ __PVT__g_way_decode__BRA__1__KET____DOT__g_dirty__DOT__dclr_all;
        CData/*0:0*/ __PVT__g_way_decode__BRA__1__KET____DOT__g_dirty__DOT__dclr_oh;
        CData/*0:0*/ __PVT__g_way_decode__BRA__1__KET____DOT__g_dirty__DOT__same_set;
        CData/*0:0*/ __PVT__g_way_decode__BRA__2__KET____DOT__do_fill;
        CData/*0:0*/ __PVT__g_way_decode__BRA__2__KET____DOT__do_write;
        CData/*0:0*/ __PVT__g_way_decode__BRA__2__KET____DOT__fill_refill;
        CData/*0:0*/ __PVT__g_way_decode__BRA__2__KET____DOT__g_dirty__DOT__dclr_all;
        CData/*0:0*/ __PVT__g_way_decode__BRA__2__KET____DOT__g_dirty__DOT__dclr_oh;
        CData/*0:0*/ __PVT__g_way_decode__BRA__2__KET____DOT__g_dirty__DOT__same_set;
        CData/*0:0*/ __PVT__g_way_decode__BRA__3__KET____DOT__do_fill;
        CData/*0:0*/ __PVT__g_way_decode__BRA__3__KET____DOT__do_write;
        CData/*0:0*/ __PVT__g_way_decode__BRA__3__KET____DOT__fill_refill;
        CData/*0:0*/ __PVT__g_way_decode__BRA__3__KET____DOT__g_dirty__DOT__dclr_all;
        CData/*0:0*/ __PVT__g_way_decode__BRA__3__KET____DOT__g_dirty__DOT__dclr_oh;
        CData/*0:0*/ __PVT__g_way_decode__BRA__3__KET____DOT__g_dirty__DOT__same_set;
        CData/*3:0*/ __PVT__valid_store__DOT__g_no_asic__DOT__g_sync__DOT__g_lutram__DOT__g_read_first__DOT__g_wren__DOT__rdata_r;
        CData/*0:0*/ __PVT__g_way_decode__BRA__0__KET____DOT_____05Fbuffer_ex152__DOT__g_pipe__DOT__g_full_reset__DOT__pipe;
        CData/*0:0*/ __PVT__g_way_decode__BRA__0__KET____DOT_____05Fbuffer_ex153__DOT__g_pipe__DOT__g_full_reset__DOT__pipe;
        CData/*4:0*/ __PVT__g_way_decode__BRA__0__KET____DOT_____05Fbuffer_ex155__DOT__g_pipe__DOT__g_full_reset__DOT__pipe;
        CData/*0:0*/ __PVT__g_way_decode__BRA__0__KET____DOT_____05Fbuffer_ex176__DOT__g_pipe__DOT__g_full_reset__DOT__pipe;
        CData/*0:0*/ __PVT__g_way_decode__BRA__0__KET____DOT__g_dirty__DOT_____05Fbuffer_ex216__DOT__g_pipe__DOT__g_full_reset__DOT__pipe;
        CData/*0:0*/ __PVT__g_way_decode__BRA__0__KET____DOT__g_dirty__DOT_____05Fbuffer_ex217__DOT__g_pipe__DOT__g_full_reset__DOT__pipe;
        CData/*0:0*/ __PVT__g_way_decode__BRA__0__KET____DOT__g_dirty__DOT_____05Fbuffer_ex218__DOT__g_pipe__DOT__g_full_reset__DOT__pipe;
        CData/*0:0*/ __PVT__g_way_decode__BRA__1__KET____DOT_____05Fbuffer_ex152__DOT__g_pipe__DOT__g_full_reset__DOT__pipe;
        CData/*0:0*/ __PVT__g_way_decode__BRA__1__KET____DOT_____05Fbuffer_ex153__DOT__g_pipe__DOT__g_full_reset__DOT__pipe;
        CData/*4:0*/ __PVT__g_way_decode__BRA__1__KET____DOT_____05Fbuffer_ex155__DOT__g_pipe__DOT__g_full_reset__DOT__pipe;
        CData/*0:0*/ __PVT__g_way_decode__BRA__1__KET____DOT_____05Fbuffer_ex176__DOT__g_pipe__DOT__g_full_reset__DOT__pipe;
        CData/*0:0*/ __PVT__g_way_decode__BRA__1__KET____DOT__g_dirty__DOT_____05Fbuffer_ex216__DOT__g_pipe__DOT__g_full_reset__DOT__pipe;
        CData/*0:0*/ __PVT__g_way_decode__BRA__1__KET____DOT__g_dirty__DOT_____05Fbuffer_ex217__DOT__g_pipe__DOT__g_full_reset__DOT__pipe;
        CData/*0:0*/ __PVT__g_way_decode__BRA__1__KET____DOT__g_dirty__DOT_____05Fbuffer_ex218__DOT__g_pipe__DOT__g_full_reset__DOT__pipe;
    };
    struct {
        CData/*0:0*/ __PVT__g_way_decode__BRA__2__KET____DOT_____05Fbuffer_ex152__DOT__g_pipe__DOT__g_full_reset__DOT__pipe;
        CData/*0:0*/ __PVT__g_way_decode__BRA__2__KET____DOT_____05Fbuffer_ex153__DOT__g_pipe__DOT__g_full_reset__DOT__pipe;
        CData/*4:0*/ __PVT__g_way_decode__BRA__2__KET____DOT_____05Fbuffer_ex155__DOT__g_pipe__DOT__g_full_reset__DOT__pipe;
        CData/*0:0*/ __PVT__g_way_decode__BRA__2__KET____DOT_____05Fbuffer_ex176__DOT__g_pipe__DOT__g_full_reset__DOT__pipe;
        CData/*0:0*/ __PVT__g_way_decode__BRA__2__KET____DOT__g_dirty__DOT_____05Fbuffer_ex216__DOT__g_pipe__DOT__g_full_reset__DOT__pipe;
        CData/*0:0*/ __PVT__g_way_decode__BRA__2__KET____DOT__g_dirty__DOT_____05Fbuffer_ex217__DOT__g_pipe__DOT__g_full_reset__DOT__pipe;
        CData/*0:0*/ __PVT__g_way_decode__BRA__2__KET____DOT__g_dirty__DOT_____05Fbuffer_ex218__DOT__g_pipe__DOT__g_full_reset__DOT__pipe;
        CData/*0:0*/ __PVT__g_way_decode__BRA__3__KET____DOT_____05Fbuffer_ex152__DOT__g_pipe__DOT__g_full_reset__DOT__pipe;
        CData/*0:0*/ __PVT__g_way_decode__BRA__3__KET____DOT_____05Fbuffer_ex153__DOT__g_pipe__DOT__g_full_reset__DOT__pipe;
        CData/*4:0*/ __PVT__g_way_decode__BRA__3__KET____DOT_____05Fbuffer_ex155__DOT__g_pipe__DOT__g_full_reset__DOT__pipe;
        CData/*0:0*/ __PVT__g_way_decode__BRA__3__KET____DOT_____05Fbuffer_ex176__DOT__g_pipe__DOT__g_full_reset__DOT__pipe;
        CData/*0:0*/ __PVT__g_way_decode__BRA__3__KET____DOT__g_dirty__DOT_____05Fbuffer_ex216__DOT__g_pipe__DOT__g_full_reset__DOT__pipe;
        CData/*0:0*/ __PVT__g_way_decode__BRA__3__KET____DOT__g_dirty__DOT_____05Fbuffer_ex217__DOT__g_pipe__DOT__g_full_reset__DOT__pipe;
        CData/*0:0*/ __PVT__g_way_decode__BRA__3__KET____DOT__g_dirty__DOT_____05Fbuffer_ex218__DOT__g_pipe__DOT__g_full_reset__DOT__pipe;
        CData/*3:0*/ __PVT__g_dirty_store__DOT__dirty_store__DOT__g_no_asic__DOT__g_sync__DOT__g_lutram__DOT__g_read_first__DOT__g_wren__DOT__rdata_r;
        IData/*19:0*/ __Vxrand___0;
        VL_IN(line_tag,19,0);
        VL_OUT(evict_tag,19,0);
        VlWide<3>/*79:0*/ __PVT__read_tag;
        VlWide<3>/*79:0*/ __PVT__line_wdata;
        VlWide<3>/*79:0*/ __PVT__tag_store__DOT__g_no_asic__DOT__g_sync__DOT__g_auto__DOT__g_read_first__DOT__g_wren__DOT__rdata_r;
        IData/*19:0*/ tag_store__DOT____Vlvbound_hfeeb3dba__0;
        IData/*19:0*/ __PVT__g_way_decode__BRA__0__KET____DOT_____05Fbuffer_ex154__DOT__g_pipe__DOT__g_full_reset__DOT__pipe;
        IData/*19:0*/ __PVT__g_way_decode__BRA__1__KET____DOT_____05Fbuffer_ex154__DOT__g_pipe__DOT__g_full_reset__DOT__pipe;
        IData/*19:0*/ __PVT__g_way_decode__BRA__2__KET____DOT_____05Fbuffer_ex154__DOT__g_pipe__DOT__g_full_reset__DOT__pipe;
        IData/*19:0*/ __PVT__g_way_decode__BRA__3__KET____DOT_____05Fbuffer_ex154__DOT__g_pipe__DOT__g_full_reset__DOT__pipe;
        VlUnpacked<VlWide<3>/*79:0*/, 32> __PVT__tag_store__DOT__g_no_asic__DOT__g_sync__DOT__g_auto__DOT__g_read_first__DOT__g_wren__DOT__ram;
        VlUnpacked<CData/*3:0*/, 32> __PVT__valid_store__DOT__g_no_asic__DOT__g_sync__DOT__g_lutram__DOT__g_read_first__DOT__g_wren__DOT__ram;
        VlUnpacked<CData/*3:0*/, 32> __PVT__g_dirty_store__DOT__dirty_store__DOT__g_no_asic__DOT__g_sync__DOT__g_lutram__DOT__g_read_first__DOT__g_wren__DOT__ram;
    };

    // INTERNAL VARIABLES
    Vrtlsim_shim__Syms* const vlSymsp;

    // CONSTRUCTORS
    Vrtlsim_shim_mini_physical_VX_cache_tags__pi143(Vrtlsim_shim__Syms* symsp, const char* v__name);
    ~Vrtlsim_shim_mini_physical_VX_cache_tags__pi143();
    VL_UNCOPYABLE(Vrtlsim_shim_mini_physical_VX_cache_tags__pi143);

    // INTERNAL METHODS
    void __Vconfigure(bool first);
};


#endif  // guard
