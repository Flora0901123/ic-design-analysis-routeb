// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design internal header
// See Vrtlsim_shim.h for the primary calling header

#ifndef VERILATED_VRTLSIM_SHIM_MINI_PHYSICAL_VX_SP_RAM__PI199_H_
#define VERILATED_VRTLSIM_SHIM_MINI_PHYSICAL_VX_SP_RAM__PI199_H_  // guard

#include "verilated.h"


class Vrtlsim_shim__Syms;

class alignas(VL_CACHE_LINE_BYTES) Vrtlsim_shim_mini_physical_VX_sp_ram__pi199 final : public VerilatedModule {
  public:

    // DESIGN SPECIFIC STATE
    VL_IN8(clk,0,0);
    VL_IN8(reset,0,0);
    VL_IN8(read,0,0);
    VL_IN8(write,0,0);
    VL_IN8(wren,0,0);
    VL_IN8(addr,7,0);
    CData/*0:0*/ __PVT__g_asic__DOT__sp_ram_asic__DOT__read_seen_q;
    VL_IN(wdata,31,0);
    VL_OUT(rdata,31,0);
    IData/*31:0*/ __PVT__g_asic__DOT__sp_ram_asic__DOT__macro_rdata;
    VlUnpacked<IData/*31:0*/, 256> __PVT__g_asic__DOT__sp_ram_asic__DOT__g_vortex_sp_32x256_w1__DOT__u_macro__DOT__mem;

    // INTERNAL VARIABLES
    Vrtlsim_shim__Syms* const vlSymsp;

    // CONSTRUCTORS
    Vrtlsim_shim_mini_physical_VX_sp_ram__pi199(Vrtlsim_shim__Syms* symsp, const char* v__name);
    ~Vrtlsim_shim_mini_physical_VX_sp_ram__pi199();
    VL_UNCOPYABLE(Vrtlsim_shim_mini_physical_VX_sp_ram__pi199);

    // INTERNAL METHODS
    void __Vconfigure(bool first);
};


#endif  // guard
