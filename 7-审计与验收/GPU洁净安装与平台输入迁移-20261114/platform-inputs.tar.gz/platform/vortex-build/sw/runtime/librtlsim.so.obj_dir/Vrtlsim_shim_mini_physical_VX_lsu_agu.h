// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design internal header
// See Vrtlsim_shim.h for the primary calling header

#ifndef VERILATED_VRTLSIM_SHIM_MINI_PHYSICAL_VX_LSU_AGU_H_
#define VERILATED_VRTLSIM_SHIM_MINI_PHYSICAL_VX_LSU_AGU_H_  // guard

#include "verilated.h"


class Vrtlsim_shim__Syms;

class alignas(VL_CACHE_LINE_BYTES) Vrtlsim_shim_mini_physical_VX_lsu_agu final : public VerilatedModule {
  public:

    // DESIGN SPECIFIC STATE
    VL_IN8(pack,1,0);
    VL_IN16(offset,11,0);
    VL_IN(base,31,0);
    VL_IN(stride,31,0);
    VL_OUT(addr,31,0);
    IData/*31:0*/ __PVT__lin_addr;
    IData/*31:0*/ __PVT__agu_csa__DOT__sum_int;
    IData/*31:0*/ __PVT__agu_csa__DOT__carry_int;

    // INTERNAL VARIABLES
    Vrtlsim_shim__Syms* const vlSymsp;

    // CONSTRUCTORS
    Vrtlsim_shim_mini_physical_VX_lsu_agu(Vrtlsim_shim__Syms* symsp, const char* v__name);
    ~Vrtlsim_shim_mini_physical_VX_lsu_agu();
    VL_UNCOPYABLE(Vrtlsim_shim_mini_physical_VX_lsu_agu);

    // INTERNAL METHODS
    void __Vconfigure(bool first);
};


#endif  // guard
