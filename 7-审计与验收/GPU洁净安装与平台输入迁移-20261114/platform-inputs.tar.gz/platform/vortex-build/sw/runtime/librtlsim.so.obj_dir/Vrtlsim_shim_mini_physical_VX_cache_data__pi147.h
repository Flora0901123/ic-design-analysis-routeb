// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design internal header
// See Vrtlsim_shim.h for the primary calling header

#ifndef VERILATED_VRTLSIM_SHIM_MINI_PHYSICAL_VX_CACHE_DATA__PI147_H_
#define VERILATED_VRTLSIM_SHIM_MINI_PHYSICAL_VX_CACHE_DATA__PI147_H_  // guard

#include "verilated.h"


class Vrtlsim_shim__Syms;

class alignas(VL_CACHE_LINE_BYTES) Vrtlsim_shim_mini_physical_VX_cache_data__pi147 final : public VerilatedModule {
  public:

    // DESIGN SPECIFIC STATE
    // Anonymous structures to workaround compiler member-count bugs
    struct {
        VL_IN8(clk,0,0);
        VL_IN8(reset,0,0);
        VL_IN8(init,0,0);
        VL_IN8(fill,0,0);
        VL_IN8(flush,0,0);
        VL_IN8(read,0,0);
        VL_IN8(write,0,0);
        VL_IN8(line_idx,4,0);
        VL_IN8(evict_way,1,0);
        VL_IN8(tag_matches,3,0);
        VL_IN8(write_byteen,7,0);
        VL_IN8(word_idx,2,0);
        VL_IN8(sector_idx,0,0);
        VL_IN8(way_idx_r,1,0);
        CData/*6:0*/ __PVT__data_addr;
        CData/*0:0*/ __PVT__g_data_slice__BRA__0__KET____DOT__slice_read;
        CData/*7:0*/ __PVT__g_data_slice__BRA__0__KET____DOT__slice_wren;
        CData/*0:0*/ __PVT__g_data_slice__BRA__1__KET____DOT__slice_read;
        CData/*7:0*/ __PVT__g_data_slice__BRA__1__KET____DOT__slice_wren;
        CData/*0:0*/ __PVT__g_data_slice__BRA__2__KET____DOT__slice_read;
        CData/*7:0*/ __PVT__g_data_slice__BRA__2__KET____DOT__slice_wren;
        CData/*0:0*/ __PVT__g_data_slice__BRA__3__KET____DOT__slice_read;
        CData/*7:0*/ __PVT__g_data_slice__BRA__3__KET____DOT__slice_wren;
        CData/*0:0*/ __PVT__g_data_slice__BRA__4__KET____DOT__slice_read;
        CData/*7:0*/ __PVT__g_data_slice__BRA__4__KET____DOT__slice_wren;
        CData/*0:0*/ __PVT__g_data_slice__BRA__5__KET____DOT__slice_read;
        CData/*7:0*/ __PVT__g_data_slice__BRA__5__KET____DOT__slice_wren;
        CData/*0:0*/ __PVT__g_data_slice__BRA__6__KET____DOT__slice_read;
        CData/*7:0*/ __PVT__g_data_slice__BRA__6__KET____DOT__slice_wren;
        CData/*0:0*/ __PVT__g_data_slice__BRA__7__KET____DOT__slice_read;
        CData/*7:0*/ __PVT__g_data_slice__BRA__7__KET____DOT__slice_wren;
        CData/*1:0*/ __PVT__hit_way_enc__DOT__g_model1__DOT__g_scan_l__BRA__1__KET____DOT__g_scan_s__BRA__0__KET____DOT__vs;
        CData/*1:0*/ __PVT__hit_way_enc__DOT__g_model1__DOT__g_scan_l__BRA__1__KET____DOT__g_scan_s__BRA__1__KET____DOT__vs;
        CData/*1:0*/ __PVT__hit_way_enc__DOT__g_model1__DOT__g_scan_l__BRA__2__KET____DOT__g_scan_s__BRA__0__KET____DOT__vs;
        CData/*0:0*/ __PVT__g_data_slice__BRA__0__KET____DOT__data_store__DOT__g_asic__DOT__sp_ram_asic__DOT__read_seen_q;
        CData/*0:0*/ g_data_slice__BRA__0__KET____DOT__data_store__DOT__g_asic__DOT__sp_ram_asic__DOT____Vcellinp__g_vortex_sp_64x128_w8__DOT__u_macro__csb0;
        CData/*0:0*/ __PVT__g_data_slice__BRA__1__KET____DOT__data_store__DOT__g_asic__DOT__sp_ram_asic__DOT__read_seen_q;
        CData/*0:0*/ g_data_slice__BRA__1__KET____DOT__data_store__DOT__g_asic__DOT__sp_ram_asic__DOT____Vcellinp__g_vortex_sp_64x128_w8__DOT__u_macro__csb0;
        CData/*0:0*/ __PVT__g_data_slice__BRA__2__KET____DOT__data_store__DOT__g_asic__DOT__sp_ram_asic__DOT__read_seen_q;
        CData/*0:0*/ g_data_slice__BRA__2__KET____DOT__data_store__DOT__g_asic__DOT__sp_ram_asic__DOT____Vcellinp__g_vortex_sp_64x128_w8__DOT__u_macro__csb0;
        CData/*0:0*/ __PVT__g_data_slice__BRA__3__KET____DOT__data_store__DOT__g_asic__DOT__sp_ram_asic__DOT__read_seen_q;
        CData/*0:0*/ g_data_slice__BRA__3__KET____DOT__data_store__DOT__g_asic__DOT__sp_ram_asic__DOT____Vcellinp__g_vortex_sp_64x128_w8__DOT__u_macro__csb0;
        CData/*0:0*/ __PVT__g_data_slice__BRA__4__KET____DOT__data_store__DOT__g_asic__DOT__sp_ram_asic__DOT__read_seen_q;
        CData/*0:0*/ g_data_slice__BRA__4__KET____DOT__data_store__DOT__g_asic__DOT__sp_ram_asic__DOT____Vcellinp__g_vortex_sp_64x128_w8__DOT__u_macro__csb0;
        CData/*0:0*/ __PVT__g_data_slice__BRA__5__KET____DOT__data_store__DOT__g_asic__DOT__sp_ram_asic__DOT__read_seen_q;
        CData/*0:0*/ g_data_slice__BRA__5__KET____DOT__data_store__DOT__g_asic__DOT__sp_ram_asic__DOT____Vcellinp__g_vortex_sp_64x128_w8__DOT__u_macro__csb0;
        CData/*0:0*/ __PVT__g_data_slice__BRA__6__KET____DOT__data_store__DOT__g_asic__DOT__sp_ram_asic__DOT__read_seen_q;
        CData/*0:0*/ g_data_slice__BRA__6__KET____DOT__data_store__DOT__g_asic__DOT__sp_ram_asic__DOT____Vcellinp__g_vortex_sp_64x128_w8__DOT__u_macro__csb0;
        CData/*0:0*/ __PVT__g_data_slice__BRA__7__KET____DOT__data_store__DOT__g_asic__DOT__sp_ram_asic__DOT__read_seen_q;
        CData/*0:0*/ g_data_slice__BRA__7__KET____DOT__data_store__DOT__g_asic__DOT__sp_ram_asic__DOT____Vcellinp__g_vortex_sp_64x128_w8__DOT__u_macro__csb0;
        VL_INW(fill_data,511,0,16);
        VL_OUTW(read_data,511,0,16);
        VlWide<16>/*511:0*/ __PVT__line_rdata;
        VL_IN64(write_word,63,0);
        VL_OUT64(__PVT__evict_byteen,63,0);
        QData/*63:0*/ __PVT__g_data_slice__BRA__0__KET____DOT__slice_wdata;
        QData/*63:0*/ __PVT__g_data_slice__BRA__1__KET____DOT__slice_wdata;
        QData/*63:0*/ __PVT__g_data_slice__BRA__2__KET____DOT__slice_wdata;
        QData/*63:0*/ __PVT__g_data_slice__BRA__3__KET____DOT__slice_wdata;
        QData/*63:0*/ __PVT__g_data_slice__BRA__4__KET____DOT__slice_wdata;
        QData/*63:0*/ __PVT__g_data_slice__BRA__5__KET____DOT__slice_wdata;
        QData/*63:0*/ __PVT__g_data_slice__BRA__6__KET____DOT__slice_wdata;
        QData/*63:0*/ __PVT__g_data_slice__BRA__7__KET____DOT__slice_wdata;
        QData/*63:0*/ __PVT__g_data_slice__BRA__0__KET____DOT__data_store__DOT__g_asic__DOT__sp_ram_asic__DOT__macro_rdata;
    };
    struct {
        QData/*63:0*/ __PVT__g_data_slice__BRA__1__KET____DOT__data_store__DOT__g_asic__DOT__sp_ram_asic__DOT__macro_rdata;
        QData/*63:0*/ __PVT__g_data_slice__BRA__2__KET____DOT__data_store__DOT__g_asic__DOT__sp_ram_asic__DOT__macro_rdata;
        QData/*63:0*/ __PVT__g_data_slice__BRA__3__KET____DOT__data_store__DOT__g_asic__DOT__sp_ram_asic__DOT__macro_rdata;
        QData/*63:0*/ __PVT__g_data_slice__BRA__4__KET____DOT__data_store__DOT__g_asic__DOT__sp_ram_asic__DOT__macro_rdata;
        QData/*63:0*/ __PVT__g_data_slice__BRA__5__KET____DOT__data_store__DOT__g_asic__DOT__sp_ram_asic__DOT__macro_rdata;
        QData/*63:0*/ __PVT__g_data_slice__BRA__6__KET____DOT__data_store__DOT__g_asic__DOT__sp_ram_asic__DOT__macro_rdata;
        QData/*63:0*/ __PVT__g_data_slice__BRA__7__KET____DOT__data_store__DOT__g_asic__DOT__sp_ram_asic__DOT__macro_rdata;
        VlUnpacked<CData/*3:0*/, 2> __PVT__hit_way_enc__DOT__g_model1__DOT__addr;
        VlUnpacked<CData/*3:0*/, 3> __PVT__hit_way_enc__DOT__g_model1__DOT__v;
        VlUnpacked<QData/*63:0*/, 128> __PVT__g_data_slice__BRA__0__KET____DOT__data_store__DOT__g_asic__DOT__sp_ram_asic__DOT__g_vortex_sp_64x128_w8__DOT__u_macro__DOT__mem;
        VlUnpacked<QData/*63:0*/, 128> __PVT__g_data_slice__BRA__1__KET____DOT__data_store__DOT__g_asic__DOT__sp_ram_asic__DOT__g_vortex_sp_64x128_w8__DOT__u_macro__DOT__mem;
        VlUnpacked<QData/*63:0*/, 128> __PVT__g_data_slice__BRA__2__KET____DOT__data_store__DOT__g_asic__DOT__sp_ram_asic__DOT__g_vortex_sp_64x128_w8__DOT__u_macro__DOT__mem;
        VlUnpacked<QData/*63:0*/, 128> __PVT__g_data_slice__BRA__3__KET____DOT__data_store__DOT__g_asic__DOT__sp_ram_asic__DOT__g_vortex_sp_64x128_w8__DOT__u_macro__DOT__mem;
        VlUnpacked<QData/*63:0*/, 128> __PVT__g_data_slice__BRA__4__KET____DOT__data_store__DOT__g_asic__DOT__sp_ram_asic__DOT__g_vortex_sp_64x128_w8__DOT__u_macro__DOT__mem;
        VlUnpacked<QData/*63:0*/, 128> __PVT__g_data_slice__BRA__5__KET____DOT__data_store__DOT__g_asic__DOT__sp_ram_asic__DOT__g_vortex_sp_64x128_w8__DOT__u_macro__DOT__mem;
        VlUnpacked<QData/*63:0*/, 128> __PVT__g_data_slice__BRA__6__KET____DOT__data_store__DOT__g_asic__DOT__sp_ram_asic__DOT__g_vortex_sp_64x128_w8__DOT__u_macro__DOT__mem;
        VlUnpacked<QData/*63:0*/, 128> __PVT__g_data_slice__BRA__7__KET____DOT__data_store__DOT__g_asic__DOT__sp_ram_asic__DOT__g_vortex_sp_64x128_w8__DOT__u_macro__DOT__mem;
    };

    // INTERNAL VARIABLES
    Vrtlsim_shim__Syms* const vlSymsp;

    // CONSTRUCTORS
    Vrtlsim_shim_mini_physical_VX_cache_data__pi147(Vrtlsim_shim__Syms* symsp, const char* v__name);
    ~Vrtlsim_shim_mini_physical_VX_cache_data__pi147();
    VL_UNCOPYABLE(Vrtlsim_shim_mini_physical_VX_cache_data__pi147);

    // INTERNAL METHODS
    void __Vconfigure(bool first);
};


#endif  // guard
