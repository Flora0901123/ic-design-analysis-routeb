// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design internal header
// See Vrtlsim_shim.h for the primary calling header

#ifndef VERILATED_VRTLSIM_SHIM_MINI_PHYSICAL_VX_FDIVSQRT_UNIT_H_
#define VERILATED_VRTLSIM_SHIM_MINI_PHYSICAL_VX_FDIVSQRT_UNIT_H_  // guard

#include "verilated.h"


class Vrtlsim_shim__Syms;

class alignas(VL_CACHE_LINE_BYTES) Vrtlsim_shim_mini_physical_VX_fdivsqrt_unit final : public VerilatedModule {
  public:

    // DESIGN SPECIFIC STATE
    // Anonymous structures to workaround compiler member-count bugs
    struct {
        VL_IN8(clk,0,0);
        CData/*0:0*/ __Vxrand___0;
        VL_IN8(reset,0,0);
        VL_IN8(enable,0,0);
        VL_IN8(mask,0,0);
        VL_IN8(fmt,1,0);
        VL_IN8(frm,2,0);
        VL_IN8(is_sqrt,0,0);
        VL_OUT8(fflags,4,0);
        CData/*0:0*/ __PVT__f32a_z;
        CData/*0:0*/ __PVT__f32a_sub;
        CData/*0:0*/ __PVT__f32b_z;
        CData/*0:0*/ __PVT__f32b_sub;
        CData/*0:0*/ __PVT__nan_a;
        CData/*0:0*/ __PVT__nan_b;
        CData/*0:0*/ __PVT__inf_a;
        CData/*0:0*/ __PVT__inf_b;
        CData/*0:0*/ __PVT__zero_a;
        CData/*0:0*/ __PVT__zero_b;
        CData/*0:0*/ __PVT__nv0_div;
        CData/*0:0*/ __PVT__rnan_div;
        CData/*0:0*/ __Vcellinp__pre_reg__enable;
        CData/*0:0*/ __Vcellinp__ini_reg__enable;
        CData/*0:0*/ __Vcellinp__conv_reg__enable;
        CData/*4:0*/ __PVT__nrm_fflags;
        CData/*0:0*/ __Vcellinp__nrm_reg__enable;
        CData/*0:0*/ __Vcellinp__g_srt__BRA__0__KET____DOT__srt_reg__enable;
        CData/*0:0*/ __Vcellinp__g_srt__BRA__1__KET____DOT__srt_reg__enable;
        CData/*0:0*/ __Vcellinp__g_srt__BRA__2__KET____DOT__srt_reg__enable;
        CData/*0:0*/ __Vcellinp__g_srt__BRA__3__KET____DOT__srt_reg__enable;
        CData/*0:0*/ __Vcellinp__g_srt__BRA__4__KET____DOT__srt_reg__enable;
        CData/*0:0*/ __Vcellinp__g_srt__BRA__5__KET____DOT__srt_reg__enable;
        CData/*0:0*/ __Vcellinp__g_srt__BRA__6__KET____DOT__srt_reg__enable;
        CData/*0:0*/ __Vcellinp__g_srt__BRA__7__KET____DOT__srt_reg__enable;
        CData/*0:0*/ __Vcellinp__g_srt__BRA__8__KET____DOT__srt_reg__enable;
        CData/*0:0*/ __Vcellinp__g_srt__BRA__9__KET____DOT__srt_reg__enable;
        CData/*0:0*/ __Vcellinp__g_srt__BRA__10__KET____DOT__srt_reg__enable;
        CData/*0:0*/ __Vcellinp__g_srt__BRA__11__KET____DOT__srt_reg__enable;
        CData/*0:0*/ __Vcellinp__g_srt__BRA__12__KET____DOT__srt_reg__enable;
        CData/*0:0*/ u_rnd__DOT____Vxrand___0;
        CData/*5:0*/ __Vfunc_sv2v_cast_081B2_signed__19__Vfuncout;
        CData/*5:0*/ __Vfunc_sv2v_cast_081B2_signed__19__inp;
        CData/*5:0*/ __Vfunc_sv2v_cast_081B2_signed__94__Vfuncout;
        CData/*5:0*/ __Vfunc_sv2v_cast_081B2_signed__94__inp;
        CData/*5:0*/ __Vfunc_sv2v_cast_081B2_signed__169__Vfuncout;
        CData/*5:0*/ __Vfunc_sv2v_cast_081B2_signed__169__inp;
        CData/*5:0*/ __Vfunc_sv2v_cast_081B2_signed__244__Vfuncout;
        CData/*5:0*/ __Vfunc_sv2v_cast_081B2_signed__244__inp;
        SData/*9:0*/ __PVT__f32a_exp;
        SData/*9:0*/ __PVT__f32b_exp;
        SData/*9:0*/ __Vfunc_sv2v_cast_6C685__2__Vfuncout;
        SData/*9:0*/ __Vfunc_sv2v_cast_6C685__2__inp;
        SData/*9:0*/ __Vfunc_sv2v_cast_6C685__3__Vfuncout;
        SData/*9:0*/ __Vfunc_sv2v_cast_6C685__3__inp;
        SData/*9:0*/ __Vfunc_sv2v_cast_6C685__5__Vfuncout;
        SData/*9:0*/ __Vfunc_sv2v_cast_6C685__5__inp;
        SData/*9:0*/ __Vfunc_sv2v_cast_6C685__6__Vfuncout;
        SData/*9:0*/ __Vfunc_sv2v_cast_6C685__6__inp;
        SData/*9:0*/ __Vfunc_sv2v_cast_6C685__77__Vfuncout;
        SData/*9:0*/ __Vfunc_sv2v_cast_6C685__77__inp;
        SData/*9:0*/ __Vfunc_sv2v_cast_6C685__78__Vfuncout;
        SData/*9:0*/ __Vfunc_sv2v_cast_6C685__78__inp;
        SData/*9:0*/ __Vfunc_sv2v_cast_6C685__80__Vfuncout;
        SData/*9:0*/ __Vfunc_sv2v_cast_6C685__80__inp;
    };
    struct {
        SData/*9:0*/ __Vfunc_sv2v_cast_6C685__81__Vfuncout;
        SData/*9:0*/ __Vfunc_sv2v_cast_6C685__81__inp;
        SData/*9:0*/ __Vfunc_sv2v_cast_6C685__152__Vfuncout;
        SData/*9:0*/ __Vfunc_sv2v_cast_6C685__152__inp;
        SData/*9:0*/ __Vfunc_sv2v_cast_6C685__153__Vfuncout;
        SData/*9:0*/ __Vfunc_sv2v_cast_6C685__153__inp;
        SData/*9:0*/ __Vfunc_sv2v_cast_6C685__155__Vfuncout;
        SData/*9:0*/ __Vfunc_sv2v_cast_6C685__155__inp;
        SData/*9:0*/ __Vfunc_sv2v_cast_6C685__156__Vfuncout;
        SData/*9:0*/ __Vfunc_sv2v_cast_6C685__156__inp;
        SData/*9:0*/ __Vfunc_sv2v_cast_6C685__227__Vfuncout;
        SData/*9:0*/ __Vfunc_sv2v_cast_6C685__227__inp;
        SData/*9:0*/ __Vfunc_sv2v_cast_6C685__228__Vfuncout;
        SData/*9:0*/ __Vfunc_sv2v_cast_6C685__228__inp;
        SData/*9:0*/ __Vfunc_sv2v_cast_6C685__230__Vfuncout;
        SData/*9:0*/ __Vfunc_sv2v_cast_6C685__230__inp;
        SData/*9:0*/ __Vfunc_sv2v_cast_6C685__231__Vfuncout;
        SData/*9:0*/ __Vfunc_sv2v_cast_6C685__231__inp;
        VL_IN(dataa,31,0);
        VL_IN(datab,31,0);
        VL_OUT(result,31,0);
        IData/*16:0*/ __PVT__mask_pipe;
        IData/*23:0*/ __PVT__f32a_sig;
        IData/*23:0*/ __PVT__f32b_sig;
        IData/*23:0*/ __PVT__f32a_norm;
        VlWide<5>/*145:0*/ __PVT__ini_in;
        VlWide<5>/*140:0*/ __PVT__pre_in;
        IData/*29:0*/ __PVT__W_corr_div;
        IData/*26:0*/ __PVT__Q_rnd;
        IData/*29:0*/ __PVT__S_corr;
        IData/*30:0*/ __PVT__W_corr_sq31;
        IData/*31:0*/ __PVT__nrm_result;
        VlWide<5>/*140:0*/ __PVT__g_srt__BRA__0__KET____DOT__s_out;
        VlWide<5>/*140:0*/ __PVT__g_srt__BRA__1__KET____DOT__s_out;
        VlWide<5>/*140:0*/ __PVT__g_srt__BRA__2__KET____DOT__s_out;
        VlWide<5>/*140:0*/ __PVT__g_srt__BRA__3__KET____DOT__s_out;
        VlWide<5>/*140:0*/ __PVT__g_srt__BRA__4__KET____DOT__s_out;
        VlWide<5>/*140:0*/ __PVT__g_srt__BRA__5__KET____DOT__s_out;
        VlWide<5>/*140:0*/ __PVT__g_srt__BRA__6__KET____DOT__s_out;
        VlWide<5>/*140:0*/ __PVT__g_srt__BRA__7__KET____DOT__s_out;
        VlWide<5>/*140:0*/ __PVT__g_srt__BRA__8__KET____DOT__s_out;
        VlWide<5>/*140:0*/ __PVT__g_srt__BRA__9__KET____DOT__s_out;
        VlWide<5>/*140:0*/ __PVT__g_srt__BRA__10__KET____DOT__s_out;
        VlWide<5>/*140:0*/ __PVT__g_srt__BRA__11__KET____DOT__s_out;
        VlWide<5>/*140:0*/ __PVT__g_srt__BRA__12__KET____DOT__s_out;
        VlWide<4>/*119:0*/ __PVT__lz_f32a__DOT__g_lzc__DOT__indices;
        VlWide<4>/*119:0*/ __PVT__lz_f32b__DOT__g_lzc__DOT__indices;
        VlWide<5>/*145:0*/ __PVT__pre_reg__DOT__g_pipe__DOT__g_no_reset__DOT__pipe;
        VlWide<5>/*140:0*/ __PVT__ini_reg__DOT__g_pipe__DOT__g_no_reset__DOT__pipe;
        VlWide<5>/*140:0*/ __PVT__g_srt__BRA__0__KET____DOT__srt_reg__DOT__g_pipe__DOT__g_no_reset__DOT__pipe;
        VlWide<5>/*140:0*/ __PVT__g_srt__BRA__1__KET____DOT__srt_reg__DOT__g_pipe__DOT__g_no_reset__DOT__pipe;
        VlWide<5>/*140:0*/ __PVT__g_srt__BRA__2__KET____DOT__srt_reg__DOT__g_pipe__DOT__g_no_reset__DOT__pipe;
        VlWide<5>/*140:0*/ __PVT__g_srt__BRA__3__KET____DOT__srt_reg__DOT__g_pipe__DOT__g_no_reset__DOT__pipe;
        VlWide<5>/*140:0*/ __PVT__g_srt__BRA__4__KET____DOT__srt_reg__DOT__g_pipe__DOT__g_no_reset__DOT__pipe;
        VlWide<5>/*140:0*/ __PVT__g_srt__BRA__5__KET____DOT__srt_reg__DOT__g_pipe__DOT__g_no_reset__DOT__pipe;
        VlWide<5>/*140:0*/ __PVT__g_srt__BRA__6__KET____DOT__srt_reg__DOT__g_pipe__DOT__g_no_reset__DOT__pipe;
        VlWide<5>/*140:0*/ __PVT__g_srt__BRA__7__KET____DOT__srt_reg__DOT__g_pipe__DOT__g_no_reset__DOT__pipe;
        VlWide<5>/*140:0*/ __PVT__g_srt__BRA__8__KET____DOT__srt_reg__DOT__g_pipe__DOT__g_no_reset__DOT__pipe;
        VlWide<5>/*140:0*/ __PVT__g_srt__BRA__9__KET____DOT__srt_reg__DOT__g_pipe__DOT__g_no_reset__DOT__pipe;
        VlWide<5>/*140:0*/ __PVT__g_srt__BRA__10__KET____DOT__srt_reg__DOT__g_pipe__DOT__g_no_reset__DOT__pipe;
        VlWide<5>/*140:0*/ __PVT__g_srt__BRA__11__KET____DOT__srt_reg__DOT__g_pipe__DOT__g_no_reset__DOT__pipe;
        VlWide<5>/*140:0*/ __PVT__g_srt__BRA__12__KET____DOT__srt_reg__DOT__g_pipe__DOT__g_no_reset__DOT__pipe;
        IData/*29:0*/ __Vfunc_sv2v_cast_D4AE7__7__Vfuncout;
        IData/*29:0*/ __Vfunc_sv2v_cast_D4AE7__7__inp;
    };
    struct {
        IData/*29:0*/ __Vfunc_sv2v_cast_D4AE7__12__Vfuncout;
        IData/*29:0*/ __Vfunc_sv2v_cast_D4AE7__12__inp;
        IData/*23:0*/ __Vfunc_u_rnd__DOT__sv2v_cast_CEDF4__74__Vfuncout;
        IData/*23:0*/ __Vfunc_u_rnd__DOT__sv2v_cast_CEDF4__74__inp;
        IData/*29:0*/ __Vfunc_sv2v_cast_D4AE7__82__Vfuncout;
        IData/*29:0*/ __Vfunc_sv2v_cast_D4AE7__82__inp;
        IData/*29:0*/ __Vfunc_sv2v_cast_D4AE7__87__Vfuncout;
        IData/*29:0*/ __Vfunc_sv2v_cast_D4AE7__87__inp;
        IData/*23:0*/ __Vfunc_u_rnd__DOT__sv2v_cast_CEDF4__149__Vfuncout;
        IData/*23:0*/ __Vfunc_u_rnd__DOT__sv2v_cast_CEDF4__149__inp;
        IData/*29:0*/ __Vfunc_sv2v_cast_D4AE7__157__Vfuncout;
        IData/*29:0*/ __Vfunc_sv2v_cast_D4AE7__157__inp;
        IData/*29:0*/ __Vfunc_sv2v_cast_D4AE7__162__Vfuncout;
        IData/*29:0*/ __Vfunc_sv2v_cast_D4AE7__162__inp;
        IData/*23:0*/ __Vfunc_u_rnd__DOT__sv2v_cast_CEDF4__224__Vfuncout;
        IData/*23:0*/ __Vfunc_u_rnd__DOT__sv2v_cast_CEDF4__224__inp;
        IData/*29:0*/ __Vfunc_sv2v_cast_D4AE7__232__Vfuncout;
        IData/*29:0*/ __Vfunc_sv2v_cast_D4AE7__232__inp;
        IData/*29:0*/ __Vfunc_sv2v_cast_D4AE7__237__Vfuncout;
        IData/*29:0*/ __Vfunc_sv2v_cast_D4AE7__237__inp;
        IData/*23:0*/ __Vfunc_u_rnd__DOT__sv2v_cast_CEDF4__299__Vfuncout;
        IData/*23:0*/ __Vfunc_u_rnd__DOT__sv2v_cast_CEDF4__299__inp;
        QData/*46:0*/ __PVT__conv_reg__DOT__g_pipe__DOT__g_no_reset__DOT__pipe;
        QData/*36:0*/ __PVT__nrm_reg__DOT__g_pipe__DOT__g_no_reset__DOT__pipe;
        VlUnpacked<VlWide<5>/*140:0*/, 14> __PVT__srt_stage;
        VlUnpacked<CData/*0:0*/, 63> __PVT__lz_f32a__DOT__g_lzc__DOT__find_first__DOT__s_n;
        VlUnpacked<CData/*4:0*/, 63> __PVT__lz_f32a__DOT__g_lzc__DOT__find_first__DOT__d_n;
        VlUnpacked<CData/*0:0*/, 63> __PVT__lz_f32b__DOT__g_lzc__DOT__find_first__DOT__s_n;
        VlUnpacked<CData/*4:0*/, 63> __PVT__lz_f32b__DOT__g_lzc__DOT__find_first__DOT__d_n;
    };

    // INTERNAL VARIABLES
    Vrtlsim_shim__Syms* const vlSymsp;

    // CONSTRUCTORS
    Vrtlsim_shim_mini_physical_VX_fdivsqrt_unit(Vrtlsim_shim__Syms* symsp, const char* v__name);
    ~Vrtlsim_shim_mini_physical_VX_fdivsqrt_unit();
    VL_UNCOPYABLE(Vrtlsim_shim_mini_physical_VX_fdivsqrt_unit);

    // INTERNAL METHODS
    void __Vconfigure(bool first);
};


#endif  // guard
