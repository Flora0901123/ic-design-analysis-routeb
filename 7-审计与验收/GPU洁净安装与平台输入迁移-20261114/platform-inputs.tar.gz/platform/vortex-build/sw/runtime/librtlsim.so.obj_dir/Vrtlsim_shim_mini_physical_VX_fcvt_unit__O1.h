// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design internal header
// See Vrtlsim_shim.h for the primary calling header

#ifndef VERILATED_VRTLSIM_SHIM_MINI_PHYSICAL_VX_FCVT_UNIT__O1_H_
#define VERILATED_VRTLSIM_SHIM_MINI_PHYSICAL_VX_FCVT_UNIT__O1_H_  // guard

#include "verilated.h"


class Vrtlsim_shim__Syms;

class alignas(VL_CACHE_LINE_BYTES) Vrtlsim_shim_mini_physical_VX_fcvt_unit__O1 final : public VerilatedModule {
  public:

    // DESIGN SPECIFIC STATE
    // Anonymous structures to workaround compiler member-count bugs
    struct {
        VL_IN8(clk,0,0);
        VL_IN8(reset,0,0);
        VL_IN8(enable,0,0);
        VL_IN8(mask,0,0);
        VL_IN8(frm,2,0);
        VL_IN8(is_itof,0,0);
        VL_IN8(is_ftoi,0,0);
        VL_IN8(is_f2f,0,0);
        VL_IN8(is_signed,0,0);
        VL_IN8(is_int64,0,0);
        VL_IN8(src_fmt,0,0);
        VL_IN8(dst_fmt,0,0);
        VL_OUT8(fflags,4,0);
        CData/*4:0*/ __PVT__mask_pipe;
        CData/*4:0*/ __PVT__renorm_shamt_s1;
        CData/*0:0*/ __PVT__lzc_neg_s1;
        CData/*0:0*/ __Vcellinp__pipe_reg2__enable;
        CData/*0:0*/ __Vcellinp__pipe_reg3__enable;
        CData/*0:0*/ __PVT__f2f_narrow_s3;
        CData/*0:0*/ __PVT__f2f_uf_s3;
        CData/*7:0*/ __PVT__final_exp_s3;
        CData/*0:0*/ __Vcellinp__pipe_reg4__enable;
        CData/*6:0*/ __PVT__fp_trunc_sh_s4;
        CData/*0:0*/ __PVT__fp_guard_s4;
        CData/*0:0*/ __Vcellinp__pipe_reg5__enable;
        CData/*4:0*/ __PVT__final_fflags_s5;
        CData/*0:0*/ __Vcellinp__pipe_reg_out__enable;
        CData/*0:0*/ fp_rounding__DOT____Vxrand___0;
        CData/*4:0*/ __Vfunc_sv2v_cast_C255F__8__Vfuncout;
        CData/*4:0*/ __Vfunc_sv2v_cast_C255F__8__inp;
        CData/*6:0*/ __Vfunc_sv2v_cast_7__28__Vfuncout;
        CData/*6:0*/ __Vfunc_sv2v_cast_7__28__inp;
        CData/*4:0*/ __Vfunc_sv2v_cast_C255F__29__Vfuncout;
        CData/*4:0*/ __Vfunc_sv2v_cast_C255F__29__inp;
        CData/*7:0*/ __Vfunc_sv2v_cast_8__34__Vfuncout;
        CData/*7:0*/ __Vfunc_sv2v_cast_8__34__inp;
        CData/*4:0*/ __Vfunc_sv2v_cast_C255F__79__Vfuncout;
        CData/*4:0*/ __Vfunc_sv2v_cast_C255F__79__inp;
        CData/*6:0*/ __Vfunc_sv2v_cast_7__99__Vfuncout;
        CData/*6:0*/ __Vfunc_sv2v_cast_7__99__inp;
        CData/*4:0*/ __Vfunc_sv2v_cast_C255F__100__Vfuncout;
        CData/*4:0*/ __Vfunc_sv2v_cast_C255F__100__inp;
        CData/*7:0*/ __Vfunc_sv2v_cast_8__105__Vfuncout;
        CData/*7:0*/ __Vfunc_sv2v_cast_8__105__inp;
        CData/*4:0*/ __Vfunc_sv2v_cast_C255F__150__Vfuncout;
        CData/*4:0*/ __Vfunc_sv2v_cast_C255F__150__inp;
        CData/*6:0*/ __Vfunc_sv2v_cast_7__170__Vfuncout;
        CData/*6:0*/ __Vfunc_sv2v_cast_7__170__inp;
        CData/*4:0*/ __Vfunc_sv2v_cast_C255F__171__Vfuncout;
        CData/*4:0*/ __Vfunc_sv2v_cast_C255F__171__inp;
        CData/*7:0*/ __Vfunc_sv2v_cast_8__176__Vfuncout;
        CData/*7:0*/ __Vfunc_sv2v_cast_8__176__inp;
        CData/*4:0*/ __Vfunc_sv2v_cast_C255F__221__Vfuncout;
        CData/*4:0*/ __Vfunc_sv2v_cast_C255F__221__inp;
        CData/*6:0*/ __Vfunc_sv2v_cast_7__241__Vfuncout;
        CData/*6:0*/ __Vfunc_sv2v_cast_7__241__inp;
        CData/*4:0*/ __Vfunc_sv2v_cast_C255F__242__Vfuncout;
        CData/*4:0*/ __Vfunc_sv2v_cast_C255F__242__inp;
        CData/*7:0*/ __Vfunc_sv2v_cast_8__247__Vfuncout;
        CData/*7:0*/ __Vfunc_sv2v_cast_8__247__inp;
        SData/*11:0*/ __PVT__unpacked_exp_s0;
        SData/*11:0*/ __PVT__norm_exp_s2;
        SData/*11:0*/ __PVT__dst_exp_s3;
        SData/*11:0*/ __Vfunc_sv2v_cast_36466__5__Vfuncout;
    };
    struct {
        SData/*11:0*/ __Vfunc_sv2v_cast_36466__5__inp;
        SData/*11:0*/ __Vfunc_sv2v_cast_36466__6__Vfuncout;
        SData/*11:0*/ __Vfunc_sv2v_cast_36466__6__inp;
        SData/*11:0*/ __Vfunc_sv2v_cast_36466__13__Vfuncout;
        SData/*11:0*/ __Vfunc_sv2v_cast_36466__13__inp;
        SData/*11:0*/ __Vfunc_sv2v_cast_36466__76__Vfuncout;
        SData/*11:0*/ __Vfunc_sv2v_cast_36466__76__inp;
        SData/*11:0*/ __Vfunc_sv2v_cast_36466__77__Vfuncout;
        SData/*11:0*/ __Vfunc_sv2v_cast_36466__77__inp;
        SData/*11:0*/ __Vfunc_sv2v_cast_36466__84__Vfuncout;
        SData/*11:0*/ __Vfunc_sv2v_cast_36466__84__inp;
        SData/*11:0*/ __Vfunc_sv2v_cast_36466__147__Vfuncout;
        SData/*11:0*/ __Vfunc_sv2v_cast_36466__147__inp;
        SData/*11:0*/ __Vfunc_sv2v_cast_36466__148__Vfuncout;
        SData/*11:0*/ __Vfunc_sv2v_cast_36466__148__inp;
        SData/*11:0*/ __Vfunc_sv2v_cast_36466__155__Vfuncout;
        SData/*11:0*/ __Vfunc_sv2v_cast_36466__155__inp;
        SData/*11:0*/ __Vfunc_sv2v_cast_36466__218__Vfuncout;
        SData/*11:0*/ __Vfunc_sv2v_cast_36466__218__inp;
        SData/*11:0*/ __Vfunc_sv2v_cast_36466__219__Vfuncout;
        SData/*11:0*/ __Vfunc_sv2v_cast_36466__219__inp;
        SData/*11:0*/ __Vfunc_sv2v_cast_36466__226__Vfuncout;
        SData/*11:0*/ __Vfunc_sv2v_cast_36466__226__inp;
        VL_IN(dataa,31,0);
        VL_OUT(result,31,0);
        IData/*31:0*/ __PVT__unpacked_mant_s0;
        VlWide<3>/*64:0*/ __PVT__aligned_mant_full_s4;
        IData/*31:0*/ __PVT__res_val_32;
        IData/*31:0*/ __PVT__g_lzc_inv__DOT__i_inv_raw;
        VlWide<5>/*159:0*/ __PVT__lzc__DOT__g_lzc__DOT__indices;
        VlWide<3>/*67:0*/ __PVT__pipe_reg2__DOT__g_pipe__DOT__g_no_reset__DOT__pipe;
        VlWide<3>/*74:0*/ __PVT__pipe_reg3__DOT__g_pipe__DOT__g_no_reset__DOT__pipe;
        VlWide<3>/*84:0*/ __PVT__pipe_reg4__DOT__g_pipe__DOT__g_no_reset__DOT__pipe;
        VlWide<3>/*74:0*/ __PVT__pipe_reg5__DOT__g_pipe__DOT__g_no_reset__DOT__pipe;
        IData/*31:0*/ __Vfunc_sv2v_cast_99F89__3__Vfuncout;
        IData/*31:0*/ __Vfunc_sv2v_cast_99F89__3__inp;
        IData/*31:0*/ __Vfunc_sv2v_cast_99F89__7__Vfuncout;
        IData/*31:0*/ __Vfunc_sv2v_cast_99F89__7__inp;
        IData/*31:0*/ __Vfunc_fp_rounding__DOT__sv2v_cast_CEDF4__70__Vfuncout;
        IData/*31:0*/ __Vfunc_fp_rounding__DOT__sv2v_cast_CEDF4__70__inp;
        IData/*31:0*/ __Vfunc_sv2v_cast_99F89__74__Vfuncout;
        IData/*31:0*/ __Vfunc_sv2v_cast_99F89__74__inp;
        IData/*31:0*/ __Vfunc_sv2v_cast_99F89__78__Vfuncout;
        IData/*31:0*/ __Vfunc_sv2v_cast_99F89__78__inp;
        IData/*31:0*/ __Vfunc_fp_rounding__DOT__sv2v_cast_CEDF4__141__Vfuncout;
        IData/*31:0*/ __Vfunc_fp_rounding__DOT__sv2v_cast_CEDF4__141__inp;
        IData/*31:0*/ __Vfunc_sv2v_cast_99F89__145__Vfuncout;
        IData/*31:0*/ __Vfunc_sv2v_cast_99F89__145__inp;
        IData/*31:0*/ __Vfunc_sv2v_cast_99F89__149__Vfuncout;
        IData/*31:0*/ __Vfunc_sv2v_cast_99F89__149__inp;
        IData/*31:0*/ __Vfunc_fp_rounding__DOT__sv2v_cast_CEDF4__212__Vfuncout;
        IData/*31:0*/ __Vfunc_fp_rounding__DOT__sv2v_cast_CEDF4__212__inp;
        IData/*31:0*/ __Vfunc_sv2v_cast_99F89__216__Vfuncout;
        IData/*31:0*/ __Vfunc_sv2v_cast_99F89__216__inp;
        IData/*31:0*/ __Vfunc_sv2v_cast_99F89__220__Vfuncout;
        IData/*31:0*/ __Vfunc_sv2v_cast_99F89__220__inp;
        IData/*31:0*/ __Vfunc_fp_rounding__DOT__sv2v_cast_CEDF4__283__Vfuncout;
        IData/*31:0*/ __Vfunc_fp_rounding__DOT__sv2v_cast_CEDF4__283__inp;
        QData/*61:0*/ __Vcellinp__pipe_reg1__data_in;
        QData/*36:0*/ __PVT__pipe_reg_out__DOT__g_pipe__DOT__g_no_reset__DOT__pipe;
        VlUnpacked<CData/*0:0*/, 63> __PVT__lzc__DOT__g_lzc__DOT__find_first__DOT__s_n;
        VlUnpacked<CData/*4:0*/, 63> __PVT__lzc__DOT__g_lzc__DOT__find_first__DOT__d_n;
    };

    // INTERNAL VARIABLES
    Vrtlsim_shim__Syms* const vlSymsp;

    // CONSTRUCTORS
    Vrtlsim_shim_mini_physical_VX_fcvt_unit__O1(Vrtlsim_shim__Syms* symsp, const char* v__name);
    ~Vrtlsim_shim_mini_physical_VX_fcvt_unit__O1();
    VL_UNCOPYABLE(Vrtlsim_shim_mini_physical_VX_fcvt_unit__O1);

    // INTERNAL METHODS
    void __Vconfigure(bool first);
};


#endif  // guard
